-module(basic_app_tests_helper).
-compile(export_all).

help() -> true.