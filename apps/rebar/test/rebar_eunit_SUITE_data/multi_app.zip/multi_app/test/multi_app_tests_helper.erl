-module(multi_app_tests_helper).
-compile(export_all).

help() -> true.