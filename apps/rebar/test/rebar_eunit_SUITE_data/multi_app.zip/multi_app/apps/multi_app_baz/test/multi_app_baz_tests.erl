-module(multi_app_baz_tests).
-compile(export_all).

-include("multi_app_baz.hrl").

sanity_test() ->
  %% check `test` dir for app is compiled and on path
  true = multi_app_baz_tests_helper:help(),
  %% check all applicable defines are included
  true = ?include_define,
  true = ?config_define,
  true = ?eunit_compile_define.