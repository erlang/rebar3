-module(multi_app_baz_tests_helper).
-compile(export_all).

help() -> true.