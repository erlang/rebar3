-module(multi_app_bar_tests_helper).
-compile(export_all).

help() -> true.