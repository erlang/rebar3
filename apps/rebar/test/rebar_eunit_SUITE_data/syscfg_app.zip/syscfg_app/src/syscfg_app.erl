-module(syscfg_app).

-include_lib("eunit/include/eunit.hrl").

file_cfg1_test() ->
    ?assert(application:get_env(syscfg_app, file_cfg1, false)).

file_cfg2_test() ->
    ?assert(application:get_env(syscfg_app, file_cfg2, false)).

cmd_cfg1_test() ->
    ?assert(application:get_env(syscfg_app, cmd_cfg1, false)).

cmd_cfg2_test() ->
    ?assert(application:get_env(syscfg_app, cmd_cfg2, false)).
